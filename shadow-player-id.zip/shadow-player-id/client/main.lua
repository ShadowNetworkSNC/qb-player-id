local displayIDs = false

-- Key controls
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlPressed(0, Config.Key) then
            if not displayIDs then
                displayIDs = true
                print("U key pressed: Displaying IDs")
            end
        else
            if displayIDs then
                displayIDs = false
                print("U key released: Hiding IDs")
            end
        end
    end
end)

-- Display IDs
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if displayIDs then
            local players = GetActivePlayers()
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            -- Display your own ID above your head
            local playerIdText = GetPlayerServerId(PlayerId())
            DrawText3D(playerCoords.x, playerCoords.y, playerCoords.z + 1.2, tostring(playerIdText))

            for _, playerId in ipairs(players) do
                if playerId ~= PlayerId() then
                    local targetPed = GetPlayerPed(playerId)
                    local targetCoords = GetEntityCoords(targetPed)
                    local distance = #(playerCoords - targetCoords)

                    if distance <= Config.Distance then
                        local targetPlayerIdText = GetPlayerServerId(playerId)
                        DrawText3D(targetCoords.x, targetCoords.y, targetCoords.z + 1.2, tostring(targetPlayerIdText))
                    end
                end
            end
        end
    end
end)

-- Function to draw 3D text
function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if onScreen then
        SetTextScale(0.5, 0.5) -- Increase text size
        SetTextFont(4)
        SetTextProportional(1)
        SetTextEntry("STRING")
        SetTextCentre(1)
        SetTextOutline()
        SetTextColour(Config.IDColor[1], Config.IDColor[2], Config.IDColor[3], Config.IDColor[4])
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end