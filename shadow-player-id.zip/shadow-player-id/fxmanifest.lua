fx_version 'cerulean'
game 'gta5'

author 'ShadowNetwork'
description 'Display Player IDs'
version 'v2'

client_scripts {
    'config.lua',
    'client/main.lua'
}