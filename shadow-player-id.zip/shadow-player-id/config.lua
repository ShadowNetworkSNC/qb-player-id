Config = {}

Config.Key = 303 -- U key
Config.Distance = 50.0 -- Distance to display IDs
Config.IDColor = {0, 255, 255, 255} -- Neon blue color (RGBA)